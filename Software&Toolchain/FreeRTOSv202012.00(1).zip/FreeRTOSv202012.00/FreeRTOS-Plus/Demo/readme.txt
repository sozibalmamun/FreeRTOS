Directories:

+ The FreeRTOS-Plus/Demo directory contains a demo application for every most of
  the FreeRTOS+ components.  Lots of the demo applications use the FreeRTOS
  Windows simulator for easy evaluation.  Be aware that FreeRTOS is much slower
  and not deterministic when executed in a simulated environment.

+ See http://www.freertos.org/plus

