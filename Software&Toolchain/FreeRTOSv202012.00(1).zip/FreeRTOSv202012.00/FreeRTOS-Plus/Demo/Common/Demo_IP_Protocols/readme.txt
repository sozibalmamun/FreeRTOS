The protocols implemented in the files and folders in this directory and its
subdirectories are intended to be demo quality examples only.  They are not
intended for inclusion in production devices.
