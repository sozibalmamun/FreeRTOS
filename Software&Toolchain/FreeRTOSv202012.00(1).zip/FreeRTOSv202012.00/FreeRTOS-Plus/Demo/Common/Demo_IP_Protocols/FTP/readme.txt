The protocols implemented in this directory are intended to be demo quality
examples only.  They are not intended for inclusion in production devices.
