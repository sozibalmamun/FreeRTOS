# Changelog for AWS IoT Jobs Library

## v1.0.0 (November 2020)

This is the first release of the AWS IoT Jobs Library in this
repository.
